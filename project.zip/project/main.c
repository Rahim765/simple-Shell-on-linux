#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<readline/readline.h>
#include<readline/history.h>
#include<signal.h>

char *strremove(char *str, const char *sub) {
    size_t len = strlen(sub);
    if (len > 0) {
        char *p = str;
        size_t size = 0;
        while ((p = strstr(p, sub)) != NULL) {
            size = (size == 0) ? (p - str) + strlen(p + len) + 1 : size - len;
            memmove(p, p + len, size - (p - str));
        }
    }
    return str;
}

int cd_exit(char** parsed)
{
    char* ListOfOwnCmds[2] = {"exit", "cd"};

    if (strcmp(parsed[0], ListOfOwnCmds[0]) == 0)
        exit(0);
    else if (strcmp(parsed[0], ListOfOwnCmds[1]) == 0)
    {
        chdir(parsed[1]);
        return 1;
    }
    else
        return 0;
}
void writeToFile (char* str)
{
    FILE* file;
    file = fopen("/home/rahim/Desktop/POS/Fos.txt", "a");
    if ( file == NULL)
    {
        fprintf(stderr, "no such file or directory!\n");
        exit(0);
    }
    if (strlen(str) != 0) {
        fprintf(file, "%s\n", str);
    }
    fclose(file);
}

void readFromFile ()
{
    FILE* file;
    file = fopen("/home/rahim/Desktop/POS/Fos.txt", "r");
    char str[100];
    if ( file == NULL)
    {
        fprintf(stderr, "History file not found");
        exit(0);
    }
    while ( fgets(str, 100, file))
    {
        add_history(strremove(str, "\n"));
    }
    fclose(file);
}

int scan(char* str)
{
    char* temp;
    temp = readline(" >> ");
    writeToFile(temp);
    if (strlen(temp) != 0)
    {
        add_history(temp);
        strcpy(str, temp);
        return 0;
    }
    else
    {
        return 1;
    }
}

void argument(char** parsed)
{

    pid_t pid = fork();
    if (pid == -1)
    {
        fprintf(stderr, "\nfailed");
        return;
    }
    else if (pid == 0)
    {
        if (execvp(parsed[0], parsed) < 0)
        {
            fprintf(stderr, "\n not executed");
        }
        exit(0);
    }
    else
    {
        wait(NULL);
        return;
    }
}

void Pipedargument(char** parsed, char** parsedpipe)
{

    int pipefd[2];
    pid_t p1, p2;

    if (pipe(pipefd) < 0)
    {
        fprintf(stderr, "\nfailed");
        return;
    }
    p1 = fork();
    if (p1 < 0)
    {
        fprintf(stderr, "\nfailed");
        return;
    }

    if (p1 == 0)
    {

        close(pipefd[0]);
        dup2(pipefd[1], STDOUT_FILENO);
        close(pipefd[1]);

        if (execvp(parsed[0], parsed) < 0)
        {
            fprintf(stderr, "\n command 1 not executed");
            exit(0);
        }
    }
    else
    {
        p2 = fork();
        if (p2 < 0)
        {
            fprintf(stderr, "\n failed");
            return;
        }
        if (p2 == 0)
        {
            close(pipefd[1]);
            dup2(pipefd[0], STDIN_FILENO);
            close(pipefd[0]);
            if (execvp(parsedpipe[0], parsedpipe) < 0)
            {
                fprintf(stderr, "\n command 2 not executed");
                exit(0);
            }
        }
        else
        {
            wait(NULL);
            wait(NULL);
        }
    }
}

int parsePipe(char* str, char** strpiped)
{
    int i;
    for (i = 0; i < 2; i++) {
        strpiped[i] = strsep(&str, "|");
        if (strpiped[i] == NULL)
            break;
    }

    if (strpiped[1] == NULL)
        return 0;
    else
        return 1;
}

void space(char* str, char** parsed)
{
    int i;

    for (i = 0; i < 100; i++) {
        parsed[i] = strsep(&str, " ");

        if (parsed[i] == NULL)
            break;
        if (strlen(parsed[i]) == 0)
            i--;
    }
}

int processString(char* str, char** parsed, char** parsedpipe)
{
    char* strpiped[2];
    int piped = 0;

    piped = parsePipe(str, strpiped);

    if (piped)
    {
        space(strpiped[0], parsed);
        space(strpiped[1], parsedpipe);
    }
    else
    {
        space(str, parsed);
    }

    if (cd_exit(parsed))
        return 0;
    else
        return 1 + piped;
}

void ctrl_c(int x)
{
    char cwd [1024];
    if (x == 2)
    {
        getcwd(cwd, sizeof(cwd));
        printf("\n%s > ", cwd);
    }
}

void clear() { printf("\033[H\033[J"); }



int main()
{
    char vorodi[1000], *parsedArgs[100];
    char* parsedArgsPiped[100];
    int flag = 0;
    char cwd[1024];

    signal(SIGINT, ctrl_c);

    readFromFile();
    while (1) {
        getcwd(cwd, sizeof(cwd));
        printf("\n%s", cwd);

        if (scan(vorodi))
            continue;

        flag = processString(vorodi,
                                 parsedArgs, parsedArgsPiped);

        if (flag == 1)
            argument(parsedArgs);

        if (flag == 2)
            Pipedargument(parsedArgs, parsedArgsPiped);
    }
    return 0;
}